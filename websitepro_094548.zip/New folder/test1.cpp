#include <stdio.h>
#include <string.h>

#define MAX_ITEMS 10
#define NAME_LENGTH 30

// Function Prototypes
void displayInventory(char names[][NAME_LENGTH], int stocks[], int count);
void updateStock(int stocks[], int count, int type); // type 1 for add, 2 for reduce
void showSummary(char names[][NAME_LENGTH], int stocks[], int count);

int main() {
    // Initializing inventory with 10 items
    char itemNames[MAX_ITEMS][NAME_LENGTH] = {
        "Apples", "Bananas", "Milk", "Bread", "Eggs", 
        "Rice", "Sugar", "Coffee", "Tea", "Butter"
    };
    int quantities[MAX_ITEMS] = {50, 30, 20, 15, 100, 40, 25, 10, 12, 8};
    
    int choice;

    while (1) {
        printf("\n--- Mini Inventory Management System ---\n");
        printf("1. Display Inventory\n");
        printf("2. Add Stock\n");
        printf("3. Reduce Stock\n");
        printf("4. Show Summary (High/Low Stock)\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        if (choice == 5) break;

        switch (choice) {
            case 1:
                displayInventory(itemNames, quantities, MAX_ITEMS);
                break;
            case 2:
                updateStock(quantities, MAX_ITEMS, 1);
                break;
            case 3:
                updateStock(quantities, MAX_ITEMS, 2);
                break;
            case 4:
                showSummary(itemNames, quantities, MAX_ITEMS);
                break;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }

    printf("Exiting system. Goodbye!\n");
    return 0;
}

// Function to print all items
void displayInventory(char names[][NAME_LENGTH], int stocks[], int count) {
    printf("\n%-3s %-15s %-10s\n", "ID", "Item Name", "Quantity");
    printf("----------------------------------\n");
    for (int i = 0; i < count; i++) {
        printf("%-3d %-15s %-10d\n", i, names[i], stocks[i]);
    }
}

// Function to add or reduce stock
void updateStock(int stocks[], int count, int type) {
    int id, amount;
    printf("Enter Item ID (0-%d): ", count - 1);
    scanf("%d", &id);

    if (id < 0 || id >= count) {
        printf("Invalid ID!\n");
        return;
    }

    printf("Enter quantity to %s: ", (type == 1) ? "add" : "remove");
    scanf("%d", &amount);

    if (type == 1) {
        stocks[id] += amount;
        printf("Stock updated successfully!\n");
    } else {
        if (stocks[id] >= amount) {
            stocks[id] -= amount;
            printf("Stock reduced successfully!\n");
        } else {
            printf("Error: Not enough stock to reduce!\n");
        }
    }
}

// Function to find Highest and Lowest stock
void showSummary(char names[][NAME_LENGTH], int stocks[], int count) {
    int highIdx = 0, lowIdx = 0;

    for (int i = 1; i < count; i++) {
        if (stocks[i] > stocks[highIdx]) highIdx = i;
        if (stocks[i] < stocks[lowIdx]) lowIdx = i;
    }

    printf("\n--- Inventory Summary ---\n");
    printf("Highest Stock: %s (%d units)\n", names[highIdx], stocks[highIdx]);
    printf("Lowest Stock:  %s (%d units)\n", names[lowIdx], stocks[lowIdx]);
}